# 'Action' class
# Created by Alex Thomas

import MiddleWare, time, random, Communication

speed = 40 # Here we set the speed to 40 out of 100
degree = 0 # use 4 point degree (0,90,180,270,360)
history = [[0,0]] # Here we create a list holing the robots movements

# While the left sensor detects something - spin left
def checkLeft():
        print 'check left'
        if MiddleWare.irLeft():
                while MiddleWare.irLeft():# While the left sensor detects something - spin right
                        MiddleWare.spinRight(speed)
                        degree - 90  
        MiddleWare.stop()

# While the right sensor detects something - spin right
def checkright():
        print 'check right'
        if MiddleWare.irRight():
                while MiddleWare.irRight():
                        MiddleWare.spinLeft(speed)
                        degree + 90
        MiddleWare.stop()

# While the center does not sensor detects something - move forward
def checkfront():
        print 'check front'
        while not (MiddleWare.irLeft() or MiddleWare.irRight()):
                if MiddleWare.getDistance() >= 0.3: # If the distance is less than 0.3, spin right for 1 second
                        MiddleWare.forward(speed)
                        print 'Moving'
                        update()
                else:
                        if random.random() > 0.5:
                                MiddleWare.spinRight(speed)
                                degree - 90
                        else:
                                MiddleWare.spinLeft(speed)
                                degree + 90
                                
                                
                MiddleWare.stop



def update():
        global history
        global degree
        
        newlocation = history[-1][:]
        
        if degree == 0:
                newlocation[1] += 1
        elif degree == 90 or -90:
                newlocation[0] += 1
        elif degree ==  180 or -180:
                newlocation[1] -= 1
        elif degree ==  270 or -270:
                 newlocation[0] -= 1
        elif degree == 360 or -360:
                 degree = 0
                 newlocation[1] += 1
  
        history.append(newlocation)
     #   Communication.send(history)
        


def goalstate():
                print 'checking ground'
                if MiddleWare.irLeftLine() or MiddleWare.irRightLine():
                        time.sleep(1)
                        history.append('goal reached')
                        print 'found'
                        
                else:
                        time.sleep(1)
                        print 'not found'

def main():
        MiddleWare.init()
      #  Communication.start()
        try:
                while True:
                        checkLeft()
                        checkright()
                        checkfront()
                        goalstate()      
        finally:
                MiddleWare.cleanup()



main()

