# Pi2Go 'revieve'
# Created by Alex Thomas

import socket
import struct

addr = '127.0.0.1'
port = 8888

def revieve():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', port))  # use MCAST_GRP instead of '' to listen only
                             # to MCAST_GRP, not all groups on MCAST_PORT

        while True:
                print sock.recv(1024)

revieve()
