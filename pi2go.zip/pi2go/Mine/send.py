# Pi2Go 'send'
# Created by Alex Thomas

import socket

class Sender:
    
    def send(self, data):
    
        addr = '127.0.0.1'
        port =  8888
    
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP,socket.IP_MULTICAST_TTL, 2)
        sock.sendto(data,(addr, port))

x = Sender()
x.send('hello')
