# Pi2Go 'memory'
# Created by Alex Thomas

class Memory:

        history = [[0,0]]

        def _init_(self):
              self.history = history #Here we create our history ,

        def update(self):
                self.newlocation = self.history[-1][:]
                self.newlocation[0] += 1
                self.history.append(self.newlocation)
                print  self.history[0]
                print  self.history[1]
                print self.history[-1]

x = Memory()
x.update()

x.update()
