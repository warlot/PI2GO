# 'Action' class
# Created by Alex Thomas

import pi2go, time, random

speed = 40 # Here we set the speed to 40 out of 100
degree = 0 # use 4 point degree (0,90,180,270,360)
history = [[0,0]] # Here we create a list holing the robots movements

# While the left sensor detects something - spin left
def checkLeft():
        print 'check left'
        if pi2go.irLeft():
                pi2go.spinRight(speed)
                degree - 90  
        pi2go.stop()

# While the right sensor detects something - spin right
def checkright():
        print 'check right'
        if pi2go.irRight():
                pi2go.spinLeft(speed)
                degree + 90
        pi2go.stop()

# While the cneter sensor detects something - move forward
def checkfront():
        print 'check front'
        if ((pi2go.irLeft() or pi2go.irRight())) == False:
                if pi2go.irCentre() == False:
                        pi2go.forward(speed)
                        print 'Moving'
                        update()       
        pi2go.stop

##if random.random() > 0.5:
##                                checkright()
##                                time.sleep(1)    
##                        else:
##                                checkLeft()
##                                time.sleep(1)

def update():
        global history
        global degree
        
        newlocation = history[-1][:]
        
        if degree == 0:
                newlocation[1] += 1
        elif degree == 90:
                newlocation[0] += 1
        elif degree ==  180:
                newlocation[1] -= 1
        elif degree ==  270:
                 newlocation[0] -= 1
        elif degree == 360:
                 degree = 0
                 newlocation[1] += 1
  
        history.append(newlocation)

        print degree
        print history[-1]

def goalstate():
                print 'checking ground'
                if pi2go.irLeftLine() or pi2go.irRightLine():
                        time.sleep(1)
                        print 'found'
                else:
                        time.sleep(1)
                        print 'not found'
   
pi2go.init()

try:
        while True:
                checkLeft()
                checkright()
                checkfront()
                goalstate()
                
finally:
        pi2go.cleanup()
