# Pi2Go 'revieve'
# Created by Alex Thomas

import socket
import struct
import thread

addr = '127.0.0.1' 
port = 8888

def start():
        print ' stating thread'
        threading.Thread(target = receive).start()
        print 'test'
        
def receive():
        print'starting thread!'
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', port))  # use MCAST_GRP instead of '' to listen only
                             # to MCAST_GRP, not all groups on MCAST_PORT
        while True:
                print sock.recv(1024)

def send(data):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.IPPROTO_IP,socket.IP_MULTICAST_TTL, 2)
        sock.sendto(data,(addr, port))
